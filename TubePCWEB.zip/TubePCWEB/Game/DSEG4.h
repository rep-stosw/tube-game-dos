//Variables
#define word_1A5502 (*(__int16 *)(DSEG4+0x00000502))
#define word_1A5504 (*(__int16 *)(DSEG4+0x00000504))
#define word_1A5506 (*(__int16 *)(DSEG4+0x00000506))
#define word_1A5508 (*(__int16 *)(DSEG4+0x00000508))
#define word_1A550A (*(__int16 *)(DSEG4+0x0000050A))

//Arrays
#define word_1A5300 ((__int16 *)(DSEG4+0x00000300))
